<?php 
include 'formulaire.phtml';
?>