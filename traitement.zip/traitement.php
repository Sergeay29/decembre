<?php

if ($_POST["inscription"]){
    $NomUser=verifInput($_POST["fname"]);
    $PrenomUser=verifInput($_POST["lname"]);
    $MotDePass=verifInput($_POST["mdp"]);
    $ConfPassword=verifInput($_POST["cmdp"]);

if(isset($NomUser) and isset($PrenomUser)and isset($MotDePass) and isset($ConfPassword)){
    echo "Inscription réussie ✔";
    header("location:http://localhost/cours%20php/model/login.php");
    exit();
}
}
function Userlogin(){
    $NomUser=verifInput($_POST["fname"]);
    $MotDePass=verifInput($_POST["mdp"]);

    if (isset($_POST["username"] )== $NomUser and isset($_POST["umdp"])==$MotDePass) {
       header("location:http://localhost/cours%20php/model/home.phtml") ;
       exit();
    }else{
        return"Login or Password Error";
    }
}


function PassEncrypt($data)
{
$keyone='Lk5Uz3slx3BrAghS1aaW5AYgWZRV0tIX5eI0yPchFz4=';
$keytwo='EZ44mFi3TlAey1b2w4Y7lVDuqO+SRxGXsa7nctnr/JmMrA2vN6EJhrvdVZbxaQs5jpSe34X3ejFK/o9+Y5c83w==';
$first_key = base64_decode($keyone);
$second_key = base64_decode($keytwo);   
   
$method = "aes-256-cbc";   
$iv_length = openssl_cipher_iv_length($method);
$iv = openssl_random_pseudo_bytes($iv_length);
       
$first_encrypted = openssl_encrypt($data,$method,$first_key, OPENSSL_RAW_DATA ,$iv);   
$second_encrypted = hash_hmac('sha3-512', $first_encrypted, $second_key, TRUE);
           
$output = base64_encode($iv.$second_encrypted.$first_encrypted);   
return $output;       
}






function VerifInput($data){
    $verifSpace=trim($data);
    $verifSlash=stripslashes($verifSpace);
    $verifChar=htmlspecialchars($verifSlash);
    return $verifChar;
}
?>